package com.mino.storagebackup
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.*
class BackupWorker(c:Context,w:WorkerParameters):CoroutineWorker(c,w){
 override suspend fun doWork():Result{
 val p=applicationContext.getSharedPreferences("mino",0);val token=p.getString("token","")?:"";val chat=p.getString("chat","")?:"";val raw=p.getString("folder","")?:""
 if(token.isBlank()||chat.isBlank()||raw.isBlank())return Result.failure()
 return try{
 val list=mutableListOf<Pair<Uri,String>>();val tree=Uri.parse(raw);walk(tree,DocumentsContract.getTreeDocumentId(tree),"",list)
 var n=1;var zip=File(applicationContext.cacheDir,"mino_$n.zip");var out=ZipOutputStream(BufferedOutputStream(FileOutputStream(zip)));var bytes=0L;val parts=mutableListOf<File>();val limit=42L*1024*1024
 for((u,name) in list){val tmp=File(applicationContext.cacheDir,"item.tmp");applicationContext.contentResolver.openInputStream(u)?.use{src->FileOutputStream(tmp).use{src.copyTo(it)}}?:continue
 if(bytes>0&&bytes+tmp.length()>limit){out.close();parts.add(zip);n++;zip=File(applicationContext.cacheDir,"mino_$n.zip");out=ZipOutputStream(BufferedOutputStream(FileOutputStream(zip)));bytes=0}
 out.putNextEntry(ZipEntry(name));tmp.inputStream().use{it.copyTo(out)};out.closeEntry();bytes+=tmp.length();tmp.delete()
 };out.close();if(zip.length()>0)parts.add(zip)else zip.delete()
 for((i,f) in parts.withIndex()){if(!send(token,chat,f,"MINO BACKUP Part ${i+1}/${parts.size}"))return Result.retry();f.delete()}
 Result.success()
 }catch(e:Exception){Result.retry()}
 }
 private fun walk(t:Uri,id:String,prefix:String,a:MutableList<Pair<Uri,String>>){
 val q=DocumentsContract.buildChildDocumentsUriUsingTree(t,id)
 applicationContext.contentResolver.query(q,arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE),null,null,null)?.use{c->while(c.moveToNext()){val x=c.getString(0);val n=c.getString(1)?:"file";val m=c.getString(2);if(m==DocumentsContract.Document.MIME_TYPE_DIR)walk(t,x,"$prefix$n/",a)else a.add(DocumentsContract.buildDocumentUriUsingTree(t,x) to "$prefix$n")}}
 }
 private fun send(tok:String,chat:String,f:File,cap:String):Boolean{
 val b="----Mino${System.currentTimeMillis()}";val c=URL("https://api.telegram.org/bot$tok/sendDocument").openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;c.connectTimeout=30000;c.readTimeout=120000;c.setRequestProperty("Content-Type","multipart/form-data; boundary=$b")
 DataOutputStream(c.outputStream).use{o->fun field(n:String,v:String){o.writeBytes("--$b\\r\\nContent-Disposition: form-data; name=\"$n\"\\r\\n\\r\\n$v\\r\\n")};field("chat_id",chat);field("caption",cap);o.writeBytes("--$b\\r\\nContent-Disposition: form-data; name=\"document\"; filename=\"${f.name}\"\\r\\nContent-Type: application/zip\\r\\n\\r\\n");f.inputStream().use{it.copyTo(o)};o.writeBytes("\\r\\n--$b--\\r\\n")}
 val code=c.responseCode;val s=(if(code in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()};c.disconnect();return code in 200..299&&s.contains("\"ok\":true")
 }
}