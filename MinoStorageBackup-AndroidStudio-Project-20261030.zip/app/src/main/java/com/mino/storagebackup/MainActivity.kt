package com.mino.storagebackup
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.widget.*
import androidx.work.*
import java.util.concurrent.TimeUnit
class MainActivity:Activity(){
 private val p by lazy{getSharedPreferences("mino",0)}
 private lateinit var token:EditText; private lateinit var chat:EditText
 override fun onCreate(b:Bundle?){super.onCreate(b)
 val l=LinearLayout(this).apply{orientation=1;setPadding(28,28,28,28)}
 l.addView(TextView(this).apply{text="MINO STORAGE BACKUP";textSize=24f})
 token=EditText(this).apply{hint="Telegram Bot Token";setText(p.getString("token",""))}
 chat=EditText(this).apply{hint="Private Channel ID";setText(p.getString("chat","-1004371840673"))}
 l.addView(token);l.addView(chat)
 l.addView(Button(this).apply{text="Choose storage folder";setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE),77)}})
 l.addView(Button(this).apply{text="Save settings";setOnClickListener{save();Toast.makeText(this@MainActivity,"Saved",0).show()}})
 l.addView(Button(this).apply{text="Enable daily backup";setOnClickListener{save();if(p.getString("folder","").isNullOrBlank()){Toast.makeText(this@MainActivity,"Choose folder first",1).show()}else{val r=PeriodicWorkRequestBuilder<BackupWorker>(24,TimeUnit.HOURS).build();WorkManager.getInstance(this@MainActivity).enqueueUniquePeriodicWork("mino_daily",ExistingPeriodicWorkPolicy.UPDATE,r);Toast.makeText(this@MainActivity,"Daily backup enabled",1).show()}}})
 l.addView(Button(this).apply{text="Run backup now";setOnClickListener{save();WorkManager.getInstance(this@MainActivity).enqueue(OneTimeWorkRequestBuilder<BackupWorker>().build())}})
 setContentView(ScrollView(this).apply{addView(l)})
 }
 private fun save(){p.edit().putString("token",token.text.toString().trim()).putString("chat",chat.text.toString().trim()).apply()}
 @Deprecated("legacy")
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==77&&c==RESULT_OK){val u=d?.data?:return;contentResolver.takePersistableUriPermission(u,d.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION));p.edit().putString("folder",u.toString()).apply();Toast.makeText(this,"Folder access saved",1).show()}}
}