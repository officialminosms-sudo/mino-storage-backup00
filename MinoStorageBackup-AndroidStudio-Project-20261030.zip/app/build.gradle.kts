plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.mino.storagebackup"; compileSdk=35; defaultConfig { applicationId="com.mino.storagebackup"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0" } }
dependencies { implementation("androidx.work:work-runtime-ktx:2.10.0"); implementation("androidx.core:core-ktx:1.15.0") }
